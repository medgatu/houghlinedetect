function [img1] = myImageFilterX(img0, h)
